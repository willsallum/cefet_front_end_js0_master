function contandoElementosDoVetor(elementos, elementoSendoProcurado) {
    let quantidade = 0;
    for (let elemento of elementos) {
        if(elemento === elementoSendoProcurado){
            quantidade += 1;
        }
    }
    return quantidade;
}
escreva(0.4, "Contando elementos do vetor", contandoElementosDoVetor([1,4,2,7,5,6,7,2,3,9,4,7], 7));

function obtemNomeDoMes(numero) {
    if (numero < 1 || numero > 12) {
        escrevaMensagem(0.5, 'Mês inválido: ' + numero);
        return null;
    }
    let meses = [
        'janeiro',
        'fevereiro',
        'março',
        'abril',
        'maio',
        'junho',
        'julho',
        'agosto',
        'setembro',
        'outubro',
        'novembro',
        'dezembro'
    ];

    return meses[--numero];
}
escreva(0.5, "Nome do mês", obtemNomeDoMes(5));
escreva(0.5, "Nome do mês", obtemNomeDoMes(13));

function calculaVelocidadeAlturaBola(velocidadeInicial, gravidade, n){
    for(let i = 1; i <= n; i++){
        escreva(3, "h(" + i + ")", calculaAlturaBola(i, velocidadeInicial, gravidade));
        escreva(3, "v(" + i + ")", calculaVelocidadeBola(i, velocidadeInicial, gravidade));
    }
}
calculaVelocidadeAlturaBola(50, 9.81, 20);

function somatorio(n){
    s=0;
    for(let i = 2; i <= n; i += 2){
        s += 1 / i;
    }
    return s;
}
escreva(4, "Somatorio", somatorio(1)); // 0
escreva(4, "Somatorio", somatorio(10)); // 1.1416666666666666
escreva(4, "Somatorio", somatorio(100)); // 2.2496026691647115

function obtemPosicaoDoElemento(vetor, elemento){
    let posicao = null;
    for(let i = 0; i <= vetor.length-1; i++)
        if(vetor[i] === elemento){
            posicao = i;
            break;
        }
    return posicao;
}
escreva(5, "posição no vetor", obtemPosicaoDoElemento([7,3,6,5,3,8,9], 3));
escreva(5, "posição no vetor", obtemPosicaoDoElemento(['Pera', 'Uva', 'Abacaxi', 'Cenoura'], 'Abacaxi'));

function calculaMediaEntreExtremos(vetor){
    let media = 0;
    let menor = vetor[0];
    let maior = vetor[0];
    for(let i = 1; i <= vetor.length-1; i++){
        if(vetor[i] <= menor)
            menor = vetor[i];
        if(vetor[i] >= maior)
            maior = vetor[i];
    }
    media = (menor + maior) / 2;
    return media;
}
escreva(6, "Média de extremos", calculaMediaEntreExtremos([3, -2, 12]));

function fibonacci(tamanhoSequencia) {
    let sequencia = [];
    
    escreva(7, 'Fib(' + tamanhoSequencia + ')', sequencia);
    return sequencia;
}

